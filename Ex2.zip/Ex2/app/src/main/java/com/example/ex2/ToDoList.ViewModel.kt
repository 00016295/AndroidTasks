package com.example.ex2

import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel

class TodoViewModel : ViewModel() {
    private val _tasks = mutableStateListOf<String>()
    val tasks: List<String> get() = _tasks

    fun addTask(task: String) {
        if (task.isNotBlank()) {
            _tasks.add(task)
        }
    }

    fun removeTask(task: String) {
        _tasks.remove(task)
    }
}